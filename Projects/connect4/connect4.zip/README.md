README.md for connect4.a# OSU_CS271
W19 Computer Science 271 Oregon State

Most of these projects are intended to be assembled with the Irvine32 library, available here: http://kipirvine.com/asm/gettingStartedVS2017/index.htmsm

This program was entirely written by Lyell Read. The Irvine Library is the work of Kip Irvine. 

Don't copy this work and call it your own. 
Do learn from this program, if you want.